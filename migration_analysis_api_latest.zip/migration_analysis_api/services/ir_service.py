import os, subprocess
from config import INPUT_DIR, OUTPUT_DIR, VBANALYZER_DIR

def find_vbproj(migration_id):
    migration_dir=os.path.join(INPUT_DIR,str(migration_id))
    if not os.path.isdir(migration_dir): raise FileNotFoundError(f'Migration input directory not found: {migration_dir}')
    found=[]
    for root,_,files in os.walk(migration_dir):
        found += [os.path.abspath(os.path.join(root,f)) for f in files if f.lower().endswith('.vbproj')]
    if not found: raise FileNotFoundError(f'No .vbproj file found inside: {migration_dir}')
    if len(found)>1: raise RuntimeError('Multiple .vbproj files found:\n'+'\n'.join(found))
    return found[0]

def find_ir_file(directory):
    expected=os.path.join(directory,'project.ir.json')
    if os.path.isfile(expected): return os.path.abspath(expected)
    for root,_,files in os.walk(directory):
        if 'project.ir.json' in files: return os.path.abspath(os.path.join(root,'project.ir.json'))
    return None

def generate_ir(migration_id):
    migration_id=str(migration_id); vbproj=find_vbproj(migration_id)
    out=os.path.join(OUTPUT_DIR,migration_id,'ir'); os.makedirs(out,exist_ok=True)
    command=['dotnet','run','--vbproj',vbproj,'--out',out]
    result=subprocess.run(command,cwd=VBANALYZER_DIR,capture_output=True,text=True)
    if result.returncode!=0: raise RuntimeError(f'VBAnalyzer failed.\nCommand: {" ".join(command)}\n\nSTDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}')
    ir=find_ir_file(out)
    if not ir: raise RuntimeError(f'VBAnalyzer completed but project.ir.json was not found in {out}.\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}')
    return {'migration_id':migration_id,'vbproj':vbproj,'ir_output_directory':os.path.abspath(out),'ir_file':ir,'status':'IR_GENERATED'}
