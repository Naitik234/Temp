import os, subprocess
from config import INPUT_DIR, OUTPUT_DIR, CONVERTER_DIR

def find_source(migration_id):
    p=os.path.join(INPUT_DIR,str(migration_id))
    if not os.path.isdir(p): raise FileNotFoundError(f'Source project not found: {p}')
    return os.path.abspath(p)

def find_ir(migration_id):
    p=os.path.join(OUTPUT_DIR,str(migration_id),'ir','project.ir.json')
    if os.path.isfile(p): return os.path.abspath(p)
    raise FileNotFoundError(f'project.ir.json not found: {p}')

def convert_project(migration_id):
    migration_id=str(migration_id); source=find_source(migration_id); ir=find_ir(migration_id)
    br=os.path.join(OUTPUT_DIR,migration_id,'br')
    if not os.path.isdir(br): raise FileNotFoundError(f'BR directory not found: {br}')
    out=os.path.join(OUTPUT_DIR,migration_id,'converted'); os.makedirs(out,exist_ok=True)
    # Replace only this command if your actual converter has different CLI arguments.
    command=['python3.11','-m','converter','--source',source,'--ir',ir,'--br',br,'--out',out]
    result=subprocess.run(command,cwd=CONVERTER_DIR,capture_output=True,text=True)
    if result.returncode!=0: raise RuntimeError(f'Converter failed.\nCommand: {" ".join(command)}\n\nSTDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}')
    return {'migration_id':migration_id,'source_project':source,'ir':ir,'br':os.path.abspath(br),'converted':os.path.abspath(out),'status':'CONVERSION_COMPLETED'}
