import os, subprocess
from config import OUTPUT_DIR, RULE_EXTRACTOR_DIR

def find_ir_file(migration_id):
    directory=os.path.join(OUTPUT_DIR,str(migration_id),'ir')
    if not os.path.isdir(directory): raise FileNotFoundError(f'IR directory not found: {directory}')
    expected=os.path.join(directory,'project.ir.json')
    if os.path.isfile(expected): return os.path.abspath(expected)
    for root,_,files in os.walk(directory):
        if 'project.ir.json' in files: return os.path.abspath(os.path.join(root,'project.ir.json'))
    raise FileNotFoundError(f'project.ir.json was not found inside: {directory}')

def generate_br(migration_id):
    migration_id=str(migration_id); ir=find_ir_file(migration_id)
    out=os.path.join(OUTPUT_DIR,migration_id,'br'); os.makedirs(out,exist_ok=True)
    command=['python3.11','-m','rule_extractor','--ir',ir,'--out',out,'--write-contexts']
    result=subprocess.run(command,cwd=RULE_EXTRACTOR_DIR,capture_output=True,text=True)
    if result.returncode!=0: raise RuntimeError(f'Rule Extractor failed.\nCommand: {" ".join(command)}\n\nSTDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}')
    files=[]
    for root,_,names in os.walk(out): files += [os.path.abspath(os.path.join(root,n)) for n in names]
    if not files: raise RuntimeError(f'Rule Extractor completed but BR output is empty: {out}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}')
    return {'migration_id':migration_id,'ir_file':ir,'br_output_directory':os.path.abspath(out),'generated_files':files,'status':'BR_GENERATED'}
