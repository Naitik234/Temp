from flask import Flask, jsonify, request
from services.ir_service import generate_ir
from services.br_service import generate_br
from services.converter_service import convert_project
from config import INPUT_DIR, OUTPUT_DIR, HOST, PORT

app=Flask(__name__)

def body():
    data=request.get_json(silent=True)
    if not isinstance(data,dict): return None, {'success':False,'message':'JSON request body is required.'}
    mid=data.get('migration_id')
    if mid is None or not str(mid).strip(): return None, {'success':False,'message':'migration_id is required.'}
    return data,None

@app.get('/health')
def health(): return jsonify({'success':True,'message':'Migration Analysis API is running','port':PORT})

@app.post('/api/ir')
def ir():
    data,err=body()
    if err:return jsonify(err),400
    mid=str(data['migration_id']).strip()
    try:return jsonify({'success':True,'message':'IR generated successfully. Waiting for human approval.','migration_id':mid,'result':generate_ir(mid)}),200
    except FileNotFoundError as e:return jsonify({'success':False,'message':str(e),'migration_id':mid}),404
    except Exception as e:return jsonify({'success':False,'message':str(e),'migration_id':mid}),500

@app.post('/api/ir/approval')
def ir_approval():
    data,err=body()
    if err:return jsonify(err),400
    if 'approved' not in data:return jsonify({'success':False,'message':'approved is required.'}),400
    mid=str(data['migration_id']).strip(); approved=data['approved'] is True
    return jsonify({'success':True,'message':'IR approved. BR generation can now start.' if approved else 'IR rejected.','migration_id':mid,'approved':approved,'next_api':'/api/br' if approved else None})

@app.post('/api/br')
def br():
    data,err=body()
    if err:return jsonify(err),400
    mid=str(data['migration_id']).strip()
    if data.get('ir_approved') is not True:return jsonify({'success':False,'message':'IR approval is required before BR generation.'}),400
    try:return jsonify({'success':True,'message':'BR generated successfully. Waiting for human approval.','migration_id':mid,'result':generate_br(mid)}),200
    except FileNotFoundError as e:return jsonify({'success':False,'message':str(e)}),404
    except Exception as e:return jsonify({'success':False,'message':str(e)}),500

@app.post('/api/br/approval')
def br_approval():
    data,err=body()
    if err:return jsonify(err),400
    if 'approved' not in data:return jsonify({'success':False,'message':'approved is required.'}),400
    mid=str(data['migration_id']).strip(); approved=data['approved'] is True
    return jsonify({'success':True,'message':'BR approved. Conversion can now start.' if approved else 'BR rejected.','migration_id':mid,'approved':approved,'next_api':'/api/convert' if approved else None})

@app.post('/api/convert')
def convert():
    data,err=body()
    if err:return jsonify(err),400
    if data.get('ir_approved') is not True:return jsonify({'success':False,'message':'IR must be approved before conversion.'}),400
    if data.get('br_approved') is not True:return jsonify({'success':False,'message':'BR must be approved before conversion.'}),400
    mid=str(data['migration_id']).strip()
    try:return jsonify({'success':True,'message':'Conversion completed successfully.','migration_id':mid,'result':convert_project(mid)}),200
    except FileNotFoundError as e:return jsonify({'success':False,'message':str(e)}),404
    except Exception as e:return jsonify({'success':False,'message':str(e)}),500

if __name__=='__main__':
    print(f'Input : {INPUT_DIR}')
    print(f'Output: {OUTPUT_DIR}')
    print(f'Server: http://{HOST}:{PORT}')
    app.run(host=HOST,port=PORT,debug=True,use_reloader=False)
