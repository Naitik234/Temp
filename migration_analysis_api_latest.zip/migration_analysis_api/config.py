import os
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
PARENT_DIR=os.path.dirname(BASE_DIR)
INPUT_DIR=os.path.join(PARENT_DIR,'input')
OUTPUT_DIR=os.path.join(PARENT_DIR,'output')
TOOLS_DIR=os.path.join(BASE_DIR,'tools')
VBANALYZER_DIR=os.path.join(TOOLS_DIR,'vbanalyzer')
RULE_EXTRACTOR_DIR=os.path.join(TOOLS_DIR,'rule_extractor')
CONVERTER_DIR=os.path.join(TOOLS_DIR,'converter')
HOST='127.0.0.1'
PORT=1300
