# Migration Analysis API

Migration ID only. No job ID and no upload/project initialization logic.

Expected sibling directories:

```text
MY_DOCS/
├── input/
│   └── 14/
│       └── <complete VB.NET project>/
│           └── *.vbproj
├── output/
└── migration_analysis_api/
```

Run:

```bash
cd migration_analysis_api
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3.11 app.py
```

Server: http://127.0.0.1:1300

## APIs

POST `/api/ir`
```json
{"migration_id":"14"}
```

POST `/api/ir/approval`
```json
{"migration_id":"14","approved":true}
```

POST `/api/br`
```json
{"migration_id":"14","ir_approved":true}
```

POST `/api/br/approval`
```json
{"migration_id":"14","approved":true}
```

POST `/api/convert`
```json
{"migration_id":"14","ir_approved":true,"br_approved":true}
```

The VBAnalyzer and Rule Extractor subprocesses are synchronous: the API waits for each command to finish and checks its return code and generated output before reporting success.

IMPORTANT: Put your actual VBAnalyzer source under `tools/vbanalyzer`, actual Rule Extractor package under `tools/rule_extractor`, and actual converter under `tools/converter`. The converter CLI in `converter_service.py` is a placeholder based on the command shape discussed; replace it with your real converter command if different.
